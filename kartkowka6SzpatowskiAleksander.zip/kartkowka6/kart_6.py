#!/usr/bin/python3.6
#-*- coding: utf-8 -*-
import modul
def zadanie():
    n = int(input("Jaka sekunda UNIX TIME?"))
    modul.timesince(n)
zadanie()
